Assignment 1: Programming Using C++
Student Name: Paul Neville
Student Number: s3420515

Enter in terminal:
./ass1 -s datastructure -d dictionary -t textfile -o outputfile

exported: 
found/not found inc. edit distance value and closest matches
	the datastructure used is appended to the outputfile
	then .txt is appended to the outputfile name specified

a .csv file and the datastructure name are exported for the word count